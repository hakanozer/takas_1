package com.worksdays.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.worksdays.models.UserModel;

@Controller
public class HomeController {
	
	final UserModel uModel;
	public HomeController( UserModel uModel ) {
		this.uModel = uModel;
	}
	
	@GetMapping("/")
	public String home() {
		String id = uModel.req.getSession().getId();
		System.out.println(id);
		return "home";
	}
	
	
	@PostMapping("/userLogin")
	public String userLogin( @RequestParam(name = "email") String emailx, @RequestParam String password, @RequestParam(defaultValue = "") String remeber_me, Model model ) {
	
		//System.out.println( "remeber_me : " + remeber_me );
		//model.addAttribute("email", email);
		//model.addAttribute("password", password);
		
		boolean status = uModel.userLogin(emailx, password, remeber_me);
		if ( status ) {
			return "redirect:/dashboard";
		}
		
		return "redirect:/";
		
	}
	
	@GetMapping("/userLogout")
	public String userLogout() {
		uModel.userLogout();
		return "redirect:/";
	}

}

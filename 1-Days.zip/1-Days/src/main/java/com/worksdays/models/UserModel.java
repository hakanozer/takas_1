package com.worksdays.models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.worksdays.entities.User;
import com.worksdays.utils.Util;

@Service
public class UserModel {

	@Autowired DriverManagerDataSource db;
	
	final public HttpServletRequest req;
	final public HttpServletResponse res;
	public UserModel( HttpServletRequest req, HttpServletResponse res ) {
		this.res = res;
		this.req = req;
	}
	
	// Prepared Stetament
	public boolean userLogin( String email, String password, String remeber_me ) {
		
		try {
			
			String sql = " select * from user where password = ? and  email = ? ";
			PreparedStatement pre = db.getConnection().prepareStatement(sql);
			pre.setString(1,  Util.MD5(password));
			pre.setString(2, email);
			ResultSet rs = pre.executeQuery();
			if (rs.next()) {
				System.out.println("User login success");
				User us = new User();
				us.setUid(rs.getInt("uid"));
				us.setEmail(email);
				req.getSession().setAttribute("user", us);
				
				// Cookie Create
				if ( remeber_me.equals("on") ) {
					Cookie cookie = new Cookie("user",  Util.sifrele( ""+us.getUid() , 5) );
					cookie.setMaxAge(60 * 60 * 24);
					res.addCookie(cookie);
				}
				
				return true;
			}else {
				System.out.println("User login fail");
				return false;
			}
		} catch (Exception e) {
			System.err.println("userLogin Error : " + e);
			return false;
		}
		
		
		
		/*
		// ' or 1=1 --
		try {
			
			String sql = "select * from user where password = '"+Util.MD5(password)+"' and email = '"+email+"'  ";
			PreparedStatement pre = db.getConnection().prepareStatement(sql);
			ResultSet rs = pre.executeQuery();
			if (rs.next()) {
				System.out.println("User login success");
			}else {
				System.out.println("User login fail");
			}
		} catch (Exception e) {
			System.err.println("userLogin Error : " + e);
		}
		*/
		
	}
	
	public User singleUser( int uid ) {
		User us = new User();
		try {
			String sql = "select * from user where uid = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(sql);
			pre.setInt(1, uid);
			ResultSet rs = pre.executeQuery();
			if ( rs.next() ) {
				us.setEmail(rs.getString("email"));
				us.setUid(uid);
				System.out.println("SQL Call");
			}
		} catch (Exception e) {
			System.err.println("singleUser Error : " + e);
		}
		return us;
	}
	
	
	public void userLogout() {
		
		Cookie cookie = new Cookie("user", "");
		cookie.setMaxAge(0);
		res.addCookie(cookie);
		
		req.getSession().removeAttribute("user");
		req.getSession().invalidate();
		
	}
	
	
}

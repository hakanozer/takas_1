package com.worksdays.utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.worksdays.entities.User;
import com.worksdays.models.UserModel;

@Service
public class Security {
	
	@Autowired UserModel userModel;
	
	final HttpServletRequest req;
	final HttpServletResponse res;
	public Security( HttpServletRequest req, HttpServletResponse res ) {
		this.req = req;
		this.res = res;
	}
	
	
	public String control( String page ) {
		
		boolean status = req.getSession().getAttribute("user") == null;
		if (status) {
			if ( req.getCookies() != null ) {
				Cookie[] arr = req.getCookies();
				for (Cookie item : arr) {
					if ( item.getName().equals("user") ) {
						String val = item.getValue();
						String uid = Util.sifreCoz(val, 5);
						
						User user = userModel.singleUser(Integer.parseInt(uid));
						if ( !user.getEmail().equals("") ) {
							req.getSession().setAttribute("user", user);
						}
					}
				}
			}
		}	
		
		status = req.getSession().getAttribute("user") == null;
		System.out.println(req.getSession().getCreationTime());
		String id = req.getSession().getId();
		System.out.println(id);
		
		
		if ( status ) {
			return "redirect:/";
		}
		
		return page;
		
	}
	
	public User info() {
		User user = new User();
		boolean status = req.getSession().getAttribute("user") != null;
		if ( status ) {
			user = (User) req.getSession().getAttribute("user");
		}
		return user;
	}
	
	

}

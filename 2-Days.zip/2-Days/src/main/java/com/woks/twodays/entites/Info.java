package com.woks.twodays.entites;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Info {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int iid;
	
	private String name;
	private String path;
	private String roles;
	private String detail;
	private Date date;
	

}

package com.woks.twodays.entites;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import customValdaiton.Category;
import lombok.Data;

@Entity
@Data
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pid;
	
	@NotNull(message = "Title Not Null")
	@NotEmpty(message = "Title Not Empty")
	@Length(min = 3, max = 30, message = "Min 3 Max 30 Length")
	private String title;
	
	@NotNull(message = "Detail Not Null")
	@NotEmpty(message = "Detail Not Empty")
	private String detail;
	
	@NotNull(message = "Price Not Null")
	@Range(min = 10, max = 10000, message = "price min = 10, max = 10000")
	private Integer price;
	
	@Category()
	private String category;
	
}

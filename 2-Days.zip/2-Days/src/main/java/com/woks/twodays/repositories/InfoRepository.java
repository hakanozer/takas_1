package com.woks.twodays.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.woks.twodays.entites.Info;

public interface InfoRepository extends JpaRepository<Info, Integer> {

}

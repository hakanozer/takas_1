package com.woks.twodays.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.woks.twodays.entites.Note;

public interface NoteRepository extends JpaRepository<Note, Integer> {

}

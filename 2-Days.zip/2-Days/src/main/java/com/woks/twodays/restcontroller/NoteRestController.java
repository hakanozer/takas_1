package com.woks.twodays.restcontroller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.woks.twodays.entites.Note;
import com.woks.twodays.repositories.NoteRepository;

@RestController
@RequestMapping("/note")
public class NoteRestController {
	
	
	final NoteRepository nRepo;
	public NoteRestController( NoteRepository nRepo ) {
		this.nRepo = nRepo;
	}
	
	
	@PostMapping("/insert")
	public Map<String, Object> insert( @Valid @RequestBody Note note ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		hm.put("status", true);
		hm.put("result", nRepo.saveAndFlush(note) );
		
		return hm;
	}
	
	
	@GetMapping("/list")
	public Map<String, Object> list( ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		hm.put("status", true);
		hm.put("result", nRepo.findAll() );
		
		return hm;
	}
	
	
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, Object> handleErr( MethodArgumentNotValidException ex ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		List<ObjectError> els = ex.getAllErrors();
		hm.put("status", false);
		hm.put("errors", els);
		
		return hm;
	}
	
	
	

}

package com.woks.twodays.restcontroller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.woks.twodays.entites.Product;
import com.woks.twodays.models.Article;
import com.woks.twodays.models.NewsData;
import com.woks.twodays.repositories.ProductRepository;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	
	
	final ProductRepository pRepo;
	final CacheManager manager;
	public ProductRestController( ProductRepository pRepo, CacheManager manager ) {
		this.pRepo = pRepo;
		this.manager = manager;
	}
	
	
	@PostMapping("/insert")
	public Map<String, Object> insert( @Valid @RequestBody Product pro ) {

		Map<String, Object> hm = new LinkedHashMap<>();
		
		hm.put("status", true);
		hm.put("result", pRepo.saveAndFlush(pro) );
		
		clearCahce("list");
		
		return hm;
	}
	
	
	@GetMapping("/list")
	@Cacheable("list")
	public Map<String, Object> list( ) {

		Map<String, Object> hm = new LinkedHashMap<>();
		
		hm.put("status", true);
		hm.put("result", pRepo.findAll() );
		
		hm.put("news", newsResult());
		
		return hm;
	}
	
	
	
	public List<Article> newsResult() {
		
		List<Article> ls = new ArrayList<>();
		try {
			
			String url = "http://newsapi.org/v2/top-headlines?country=tr&apiKey=38a9e086f10b445faabb4461c4aa71f8";
			RestTemplate restTemplate = new RestTemplate();
			String data = restTemplate.getForObject(url, String.class);
			
			Gson gson = new Gson();
			NewsData newsData = gson.fromJson(data, NewsData.class);
			
			ls = newsData.getArticles();
			
		} catch (Exception e) {
			System.err.println("News Err : " + e);
		}
		return ls;
	}
	
	
	
	
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, Object> handleErr( MethodArgumentNotValidException ex ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		List<ObjectError> els = ex.getAllErrors();
		List<HashMap<String, String>> lss = new ArrayList<>();
		for (ObjectError errItem : els) {
			HashMap<String, String> erhm = new HashMap<>(); 
			String message = errItem.getDefaultMessage();
			String item = (( FieldError ) errItem).getField();
			erhm.put("field", item);
			erhm.put("message", message);
			lss.add(erhm);
		}
		
		hm.put("status", false);
		hm.put("errors", lss);
		
		return hm;
	}
	
	
	public void clearCahce( String cacheName ) {
		manager.getCache(cacheName).clear();
	}

}

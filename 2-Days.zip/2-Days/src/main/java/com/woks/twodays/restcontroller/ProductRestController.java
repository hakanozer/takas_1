package com.woks.twodays.restcontroller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.woks.twodays.entites.Product;
import com.woks.twodays.repositories.ProductRepository;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	
	
	final ProductRepository pRepo;
	public ProductRestController( ProductRepository pRepo ) {
		this.pRepo = pRepo;
	}
	
	
	@PostMapping("/insert")
	public Map<String, Object> insert( @RequestBody Product pro ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		hm.put("status", true);
		hm.put("result", pRepo.saveAndFlush(pro) );
		
		return hm;
	}
	
	
	@GetMapping("/list")
	public Map<String, Object> list(  ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		hm.put("status", true);
		hm.put("result", pRepo.findAll() );
		
		return hm;
	}
	

}

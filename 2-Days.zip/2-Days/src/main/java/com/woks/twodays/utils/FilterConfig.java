package com.woks.twodays.utils;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig implements Filter {
	
	@Autowired Util util;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		

		HttpServletRequest req = (HttpServletRequest) request;
		String path = req.getRequestURI();
		
		if ( !path.contains("h2-console") ) {
			util.info(path);
		}

		chain.doFilter(request, response);
		
	}
	
	

}

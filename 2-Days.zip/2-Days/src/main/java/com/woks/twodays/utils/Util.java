package com.woks.twodays.utils;

import java.util.Collection;
import java.util.Date;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.woks.twodays.entites.Info;
import com.woks.twodays.repositories.InfoRepository;

@Service
public class Util {
	
	final InfoRepository iRepo;
	public Util( InfoRepository iRepo ) {
		this.iRepo = iRepo;
	}
	
	public void info(String path) {
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		StringBuilder builder = new StringBuilder();
		Collection<? extends GrantedAuthority> roles = auth.getAuthorities();
		for (GrantedAuthority item : roles) {
			builder.append(item.getAuthority());
			builder.append(" ");
		}
		
		String name = auth.getName();
		String detail = ""+auth.getDetails();
		
		Info i = new Info();
		i.setDate(new Date());
		i.setDetail(detail);
		i.setName(name);
		i.setPath(path);
		i.setRoles(builder.toString());
		
		iRepo.saveAndFlush(i);
		
		System.out.println(name + " " + path + " " + builder.toString()  + " " + detail);
	}
	

	public static String MD5(String md5) {
	   try {
	        java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
	        byte[] array = md.digest(md5.getBytes());
	        StringBuffer sb = new StringBuffer();
	        for (int i = 0; i < array.length; ++i) {
	          sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
	       }
	        return sb.toString();
	    } catch (java.security.NoSuchAlgorithmException e) {
	    }
	    return null;
	}
	
	
	

	
}

package customValdaiton;

import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CategoryValid implements ConstraintValidator<Category, String> {

	List<String> cats = Arrays.asList("Elektronik", "Spor", "Tekstil", "Yemek");
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		return cats.contains(value);
	}

	
	
}
